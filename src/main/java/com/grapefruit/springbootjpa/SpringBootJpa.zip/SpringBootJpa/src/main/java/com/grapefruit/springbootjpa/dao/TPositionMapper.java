package com.grapefruit.springbootjpa.dao;

import com.grapefruit.springbootjpa.entity.Position;

public interface TPositionMapper {
    int insert(Position record);

    int insertSelective(Position record);
}