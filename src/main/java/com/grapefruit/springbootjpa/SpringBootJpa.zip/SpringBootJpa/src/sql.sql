## 父类
create table t_super_class
(
    id          tinyint primary key auto_increment,
    name        varchar(20) not null comment '父类名称',

```sql
creator     varchar(40) comment '创建者',
modifier    varchar(40) comment '修改者',

creat_time  varchar(20) comment '创建时间',
modify_time varchar(20) comment '修改时间'
```
 ) ENGINE = InnoDB
  AUTO_INCREMENT 5
  auto_increment = 1;

#子类(TINYINT -128，127  SMALLINT -32 768,32 767)
create table t_sub_class
(
    id          int primary key auto_increment,
    name        varchar(20) not null comment '子类名称',
    score       SMALLINT    not null comment '子类分数',
    parent_id   int         not null comment '父类ID',
    creator     varchar(40) comment '创建者',
    modifier    varchar(40) comment '修改者',
    creat_time  varchar(20) comment '创建时间',
    modify_time varchar(20) comment '修改时间'
) ENGINE = InnoDB
  AUTO_INCREMENT 8
  auto_increment = 1
  DEFAULT CHARSET utf8mb4;

#职位表
create table t_position
(
    id          int primary key auto_increment comment '职位主键',
    class       varchar(20) not null comment '职位类别',
    level       SMALLINT    not null comment '职位级别',

```sql
score       smallint    not null comment '职位级别分数',

child_score SMALLINT    not null comment '必须子类的分数',
parent_size SMALLINT    not null comment '父类的数量',

creator     varchar(40) comment '创建者',
modifier    varchar(40) comment '修改者',

creat_time  varchar(20) comment '创建时间',
modify_time varchar(20) comment '修改时间'
```
) ENGINE = InnoDB
  AUTO_INCREMENT 100
  auto_increment = 1
  DEFAULT CHARSET utf8mb4;

